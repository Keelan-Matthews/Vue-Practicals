export const taskData = [
  {
    id: 1,
    title: 'Daily',
    task: [
      { details: 'Drinking the coffee'},
      { details: 'Making the coffee'},
      { details: 'Burning tea'}
    ],
    active: false
  },
  {
    id: 2,
    title: 'Weekly',
    task: [
      { details: 'Picking up the coffee'}
    ],
    active: true
  }
]
